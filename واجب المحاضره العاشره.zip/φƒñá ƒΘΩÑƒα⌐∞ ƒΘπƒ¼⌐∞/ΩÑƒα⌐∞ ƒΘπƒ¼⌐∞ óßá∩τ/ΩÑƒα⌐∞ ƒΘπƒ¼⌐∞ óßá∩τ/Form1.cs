﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace محاضره_العاشره_تطبيق
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void driveListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dirListBox1.Path = driveListBox1.Drive;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Items.Add("*.jpg");
            comboBox1.Items.Add("*.txt");
            comboBox1.SelectedIndex = 1;
        }

        private void fileListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label1.Text = fileListBox1.Path + "\\" + fileListBox1.FileName;
            label2.Text = Path.GetFileName(label1.Text);
            label3.Text = Path.GetExtension(label1.Text);
            if(label3.Text.Trim().ToLower()==".txt")
            {
                richTextBox1.Text = File.ReadAllText(label1.Text);
                pictureBox1.Image = null;
            }
            else if(label3.Text.ToLower()==".png"||label3.Text.ToLower()==".jpg")
            {
                pictureBox1.Image = Image.FromFile(label1.Text);
            }
             
        }
    
        private void dirListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fileListBox1.Path = dirListBox1.Path;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fileListBox1.Pattern = comboBox1.Text.Trim();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

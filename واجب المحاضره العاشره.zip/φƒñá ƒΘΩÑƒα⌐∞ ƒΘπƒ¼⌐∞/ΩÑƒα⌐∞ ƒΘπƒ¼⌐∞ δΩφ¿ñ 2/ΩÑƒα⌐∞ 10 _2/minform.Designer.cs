﻿namespace محاضره_10__2
{
    partial class minform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.اToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اضافهطلابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضبياناتطلابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ملفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.اToolStripMenuItem,
            this.ملفToolStripMenuItem,
            this.خروجToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(514, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // اToolStripMenuItem
            // 
            this.اToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.اضافهطلابToolStripMenuItem,
            this.عرضبياناتطلابToolStripMenuItem});
            this.اToolStripMenuItem.Name = "اToolStripMenuItem";
            this.اToolStripMenuItem.Size = new System.Drawing.Size(111, 20);
            this.اToolStripMenuItem.Text = "ادارة بيانات الطلاب";
            this.اToolStripMenuItem.Click += new System.EventHandler(this.اToolStripMenuItem_Click);
            // 
            // اضافهطلابToolStripMenuItem
            // 
            this.اضافهطلابToolStripMenuItem.Name = "اضافهطلابToolStripMenuItem";
            this.اضافهطلابToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.اضافهطلابToolStripMenuItem.Text = "اضافه طلاب";
            this.اضافهطلابToolStripMenuItem.Click += new System.EventHandler(this.اToolStripMenuItem_Click);
            // 
            // عرضبياناتطلابToolStripMenuItem
            // 
            this.عرضبياناتطلابToolStripMenuItem.Name = "عرضبياناتطلابToolStripMenuItem";
            this.عرضبياناتطلابToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.عرضبياناتطلابToolStripMenuItem.Text = "عرض بيانات طلاب";
            this.عرضبياناتطلابToolStripMenuItem.Click += new System.EventHandler(this.عرضبياناتطلابToolStripMenuItem_Click);
            // 
            // ملفToolStripMenuItem
            // 
            this.ملفToolStripMenuItem.Name = "ملفToolStripMenuItem";
            this.ملفToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.ملفToolStripMenuItem.Text = "ملف ";
            // 
            // خروجToolStripMenuItem
            // 
            this.خروجToolStripMenuItem.Name = "خروجToolStripMenuItem";
            this.خروجToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.خروجToolStripMenuItem.Text = "خروج";
            // 
            // minform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 261);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "minform";
            this.Text = "minform";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem اToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem اضافهطلابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عرضبياناتطلابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ملفToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجToolStripMenuItem;
    }
}
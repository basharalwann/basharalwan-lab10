﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace محاضره_10__2
{
    public partial class Form1 : Form
    {
        public static  student[] s =new student[100];
        public static int count = 0;
        public Form1()
        {
            InitializeComponent();
        }
        bool isChoceImage = false;
        private void button1_Click(object sender, EventArgs e)
        {
            if (count < 100)
            {
                if (isChoceImage)
                {
                    s[count] = new student();
                    s[count].SetNumber(Convert.ToInt32(numericUpDown1.Value));
                    s[count].SetName(textBox1.Text);
                    s[count].SetBirthdate(dateTimePicker1.Text);
                    s[count].SetImgPath(openFileDialog1.FileName);
                    count++;
                    isChoceImage = false;
                    pictureBox1.Image = null;
                    numericUpDown1.Value= 0;
                    textBox1.Text = "";
                    MessageBox.Show("تم إضافة الطالب بنجاح", "نجاح");
                }
                else
                {
                    MessageBox.Show("الرجاء اختيار صورة الطالب", "تحذير");
                }
            }
            else
            {
                MessageBox.Show("الحد المسموح به مئة طالب فقط", "تحذير");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //openFileDialog1.Filter = "img(*.jpg)|*.jpg|img(*.bmp;*.png)|*.bmp;*.png";
            //if (openFileDialog1.ShowDialog() == DialogResult.OK)
            //{
            //    pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
            //    isChoceImage = true;
            //}
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "img(*.jpg)|*.jpg|img(*.bmp;*.png)|*.bmp;*.png";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                isChoceImage = true;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

    }
}

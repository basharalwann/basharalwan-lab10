﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace محاضره_10__2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
       public int n;
   
        // عند تحميل الفورم Form3
        private void Form3_Load(object sender, EventArgs e)
        {
            // تحميل بيانات الطالب
            loadStudentData();
        }

        // دالة لتحميل بيانات الطالب
        int index = Form2.index;
        void loadStudentData()
        {
            // افترض أن Form2.index هو مؤشر الطالب الحالي
          
            // تعيين قيمة numericUpDown1 من الرقم المخزن للطالب
            numericUpDown1.Value = Convert.ToDecimal(Form1.s[index].GetNumber());
            // تعيين اسم الطالب في textBox1
            textBox1.Text = Form1.s[index].GetName();
            // تعيين تاريخ الميلاد للطالب في dateTimePicker1
            dateTimePicker1.Text = Form1.s[index].GetBirthdate();
            // تحميل صورة الطالب في pictureBox1
            pictureBox1.Image = Image.FromFile(Form1.s[index].GetImgPath());
        }

        // متغير لتحديد إذا تم تحديث الصورة أم لا
        private bool isUpdateImage = false;

        // زر "حفظ" - لحفظ التعديلات التي أجريت على بيانات الطالب
        private void button1_Click(object sender, EventArgs e)
        {
            // تحديث اسم الطالب
            Form1.s[index].SetName(textBox1.Text);
            // تحديث رقم الطالب
            Form1.s[index].SetNumber(Convert.ToInt32(numericUpDown1.Value));
            // تحديث تاريخ الميلاد للطالب
            Form1.s[index].SetBirthdate(dateTimePicker1.Text);

            // إذا تم تحديث الصورة
            if (isUpdateImage)
            {
                // تعيين مسار الصورة الجديدة
                Form1.s[index].SetImgPath(openFileDialog1.FileName);
            }

            // إغلاق النافذة بعد الحفظ
            Close();
        }

        // زر "إلغاء" - لإغلاق الفورم دون حفظ التعديلات
        private void button2_Click(object sender, EventArgs e)
        {
            // إغلاق النافذة
            Close();
        }

        // حدث عند النقر على الرابط لتغيير صورة الطالب
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // تعيين نوع الملفات المقبولة لفتح الصور
            openFileDialog1.Filter = "Image files (*.jpg;*.bmp;*.png)|*.jpg;*.bmp;*.png";

            // إذا تم اختيار ملف صورة
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // تحديد أن الصورة تم تحديثها
                isUpdateImage = true;
                // تحميل الصورة الجديدة في pictureBox1
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
            }
        }


    }
}

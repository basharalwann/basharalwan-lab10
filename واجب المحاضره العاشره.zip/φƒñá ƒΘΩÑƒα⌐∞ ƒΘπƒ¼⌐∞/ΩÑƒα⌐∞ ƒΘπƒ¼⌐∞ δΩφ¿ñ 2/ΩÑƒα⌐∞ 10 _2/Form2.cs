﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace محاضره_10__2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        // دالة لتحميل بيانات الطلاب
        void loadStudentsData()
        {
            // حلقة لملء قائمة الطلاب في listBox1 و listBox2 و listBox3
            for (int i = 0; i < Form1.count; i++)
            {
                // إضافة الرقم التعريفي للطالب في listBox1
                listBox1.Items.Add(Form1.s[i].GetNumber().ToString());

                // إضافة اسم الطالب في listBox2
                listBox2.Items.Add(Form1.s[i].GetName().ToString());

                // إضافة تاريخ ميلاد الطالب في listBox3
                listBox3.Items.Add(Form1.s[i].GetBirthdate().ToString());

                // عرض صورة الطالب في pictureBox1
                pictureBox1.Image = Image.FromFile(Form1.s[i].GetImgPath());
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

            }
        }

        // معالج الحدث عند تحميل النموذج Form2
        private void Form2_Load(object sender, EventArgs e)
        {
            loadStudentsData();
            // ربط حدث تغيير الفهرس للمربعات الثلاثة مع دالة findSelectedIndexList
            listBox1.SelectedIndexChanged += findSelectedIndexList;
            listBox2.SelectedIndexChanged += findSelectedIndexList;
            listBox3.SelectedIndexChanged += findSelectedIndexList;
           
        }


// تعريف متغير ثابت لمتابعة فهرس العنصر المحدد
public static int index = -1;

        // دالة لمعالجة تغيير الفهرس للمربعات الثلاثة
        void findSelectedIndexList(object sender, EventArgs e)
        {
            // التحقق من أن العنصر المحدد صالح
            if (((ListBox)sender).SelectedIndex != -1)
            {
                // مزامنة فهرس المربعات الثلاثة
                index = listBox3.SelectedIndex = listBox2.SelectedIndex = listBox1.SelectedIndex;/*((ListBox)sender).SelectedIndex;*/

                // عرض صورة الطالب المحدد
                pictureBox1.Image = Image.FromFile(Form1.s[index].GetImgPath());
            }
        }

        // معالج الحدث عند الضغط على زر الحذف (button1)
        private void button1_Click(object sender, EventArgs e)
        {
            // التحقق من وجود عنصر محدد في listBox1
            if (listBox1.SelectedItem != null)
            {
                // إزالة العنصر المحدد من المربعات الثلاثة
                listBox1.Items.Remove(listBox1.SelectedItem);
                listBox2.Items.RemoveAt(index);
                listBox3.Items.RemoveAt(index);

                // تحريك بيانات الطلاب في المصفوفة لتغطية العنصر المحذوف
                for (int i = index; i < Form1.count - 1; i++)
                {
                    Form1.s[i] = Form1.s[i + 1];
                }

                // تقليل عدد الطلاب في القائمة
                Form1.count--;

                // تحديث العرض بعد الحذف
                if (Form1.count >= 1)
                {
                    // عرض صورة الطالب الأول بعد الحذف
                    pictureBox1.Image = Image.FromFile(Form1.s[0].GetImgPath());
                    listBox1.SelectedIndex = listBox2.SelectedIndex = listBox3.SelectedIndex = 0;
                }
                else
                {
                    // مسح الصورة في حال عدم وجود طلاب
                    pictureBox1.Image = null;
                }
            }
        }

        // معالج الحدث عند الضغط على زر الإغلاق (button4)
        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // معالج الحدث عند الضغط على زر التعديل (button3)
        private void button3_Click(object sender, EventArgs e)
        {
            // التحقق من وجود عنصر محدد في listBox1
            if (listBox1.SelectedItem != null)
            {
                // إنشاء نموذج جديد لفتح نافذة التعديل (Form3)
                Form3 f = new Form3();
                f.ShowDialog();
                // تحديث المربعات الثلاثة بالبيانات المعدلة
                listBox1.Items[index] = Form1.s[index].GetNumber().ToString();
                listBox2.Items[index] = Form1.s[index].GetName().ToString();
                listBox3.Items[index] = Form1.s[index].GetBirthdate().ToString();

                // تحديث الصورة في pictureBox1
                pictureBox1.Image = Image.FromFile(Form1.s[index].GetImgPath());
            }
        }

        // معالج الحدث عند الضغط على زر التحديث (button2)
        private void button2_Click(object sender, EventArgs e)
        {
            // مسح جميع العناصر في المربعات الثلاثة
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();

            // إعادة تحميل بيانات الطلاب من جديد
            loadStudentsData();
        }

 
    }
}
